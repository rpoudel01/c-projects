/******************************************************************************

Welcome to GDB Online.
G
*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    //build a program that checks odd /even numbers
    
    int number;
    cout << "enter a number: ";
    cin >>number;
    
    if(number % 2==0)
    {
        cout<<"Number entered is even"<<endl;
    }
        
        else{
            cout<<"it's a odd number"<<endl;
        }

    return 0;
}