/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include<climits>
using namespace std;

int main()
{
  int yearofBirth= 1995;
  char gender = 'f';
  bool isolderThan18 = true;
  float averageGrade =4.5;
  double balance = 2345678;
  
  cout<< "size of int is " <<sizeof(int)<<"bytes"<<endl;
  cout<< "Int min value is"<< INT_MIN <<endl;
  cout << "Int max value is "<< INT_MAX <<endl;
  cout <<"size of unsigned int"<< sizeof (unsigned int )<< "bytes\n";
  cout<< "size of bool is " << sizeof(bool) << "bytes\n";
  cout << "size of char is "<< sizeof(float)<< "bytes\n";
  cout <<"size of float is"<< sizeof(double)<<"bytes\n";
  

    return 0;
}