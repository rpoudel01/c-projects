/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
     cout<<(int)'a'<<endl;
    cout<<int('a')<<endl;
cout<<int('A')<<endl;


cout<<char(65)<<endl;

char c1,c2,c3,c4,c5;
cout<<"Enter 5 letters: ";
cin >> c1>> c2>>c3>>c4>>c5;

cout<<"ASCII message:"<< int(c1)<<" "<<int (c2)<< " "<<int(c3)<<" "<<int(c4)<<" "<<int(c5);// ciphered hello






    return 0;
}