/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    
// user enters a side of length of a triangle (a,b,c)
//program should write out whether that triangle is equilateral, isosceles or scalene 


int side1, side2, side3;

cout << "please enter side1: ";
cin>> side1;

cout<< "please enter side2: ";
cin>>side2;

cout<< "please enter side3: ";
cin>>side3;

if (side1==side2 && side2==side3){
cout<<"It's a equilateral triangle";
}
else {
if(side1!=side2 && side2!=side3 && side1!=side3){
    cout<<"it's a scalene triangle ";
}
else{
    cout<<"it's a isosceles triangle";
}
    return 0;
}
}
