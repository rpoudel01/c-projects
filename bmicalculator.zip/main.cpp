/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    //program to calculate your own BMI SIMPLY A BMI calculator
    //BMI calculator
    // weight /height
    // underweight <18.5
    // normal weight :18.5 -24.9
    // overweioght  >25
    
float weight,height,bmi;
cout<<"enter your height in (m) , enter your weight in kg: ";
cin>>height>>weight;
bmi = weight/(height*height);

if (bmi < 18.5){
    cout<<"underweight "<<endl;
}
else if(bmi>25){
cout<<"overweight"<<endl;

cout<<"your bmi is " <<bmi;
}
else{
    cout << "Normal Weight  "<<endl;

}

    return 0;
}