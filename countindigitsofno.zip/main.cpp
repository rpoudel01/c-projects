/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
   //building a program how many digits a program contains
    
    int number ;
    cout<< "number : ";
    cin>>number;
    
    if (number ==0)
     cout << "you have entered 0.\n";
     
     else {
         //1325
         //counter =0
         
         if (number<0)
         number= -1*number;
         
         int counter =0;
         while (number >0){
             //number =number/10;
             number /=10;
             counter++; //3
         }
         cout<<"number countains "<< counter<<" digits\n ";
             
         }
           return 0;
}