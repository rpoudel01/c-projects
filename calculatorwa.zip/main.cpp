/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    //switch case statement  part 1 build a calculator app:
    
    float num1, num2;
    char operation;
    
    cout<< "** calculator**";
    cin>>num1>>operation >>num2;
    
    switch(operation){
        case '-': cout <<num1<<operation<<num2<<"=" << num1-num2;break;
        case '+':cout <<num1<<operation<<num2<<"="<< num1 + num2;break;
        case '/': cout <<num1<<operation<<num2<<"=" << num1 / num2;break;
        case '*':cout <<num1<<operation<<num2<<"="<< num1 * num2;break;
        case '%': 
                bool isNum1Int, isNum2Int;
               isNum1Int= ((int)num1 == num1) ;//5==5.0
                isNum2Int= ((int)num2 == num2) ;
                
                if (isNum1Int && isNum2Int){
                    cout <<num1<<operation<<num2<<"="<<(int)num1 % (int)num2;
                }
                else {
                    cout <<"Not valid!";
                }
                break;
        default :cout<<"not valid operation!"<<endl;
       
    }
 
    return 0;
}