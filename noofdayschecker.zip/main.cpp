/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
int year, month;
cout<<" year "<< "month : ";
cin >>year>>month;
    
switch(month)
    {
case 2: (year %4 ==0 && year%100 !=0 || year% 400==0)?
        cout<<"has 29 days" : cout<< "has 28 days"; break;
case 4:
case 6:
case 9:
case 11:cout<<"30 days month";break;
case 1:
case 3:
case 5:
case 7:
case 8:
case 10:
case 12: cout <<"31 days a month ";break;

default: cout<< "not valid!";
}

    return 0;
}