/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    // write out all the numbers between 100-500 that are divisible by 3 and 5

int counter = 100;
while(counter <=500){
    
    if (counter %3==0 && counter%5==0)
        cout<<counter <<"is divisible \n ";
    counter++;
}
    return 0;
}