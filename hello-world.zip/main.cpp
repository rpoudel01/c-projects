/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

class Car{
public:
    int price;
    string model;
    int year;
};

int main()
{
    
 Car car1;
 Car car2;
 
 car1.model = "Lexus";
 car1.price = 20000;
 car1.year= 2017;
 
 car2.model = "Camry";
 car2.price = 18000;
 car2.year= 1989;
 
cout<<"CAR C1"<<"\n"<<car1.model<<" \n"<<car1.price<<"\n" << car1.year<<endl;
cout<<"\n"<<"\n"<<endl;
cout<<"CAR C2"<<"\n"<<car2.model<<"\n"<<car2.price<<"\n"<<car2.year<<endl;

    return 0;
}
